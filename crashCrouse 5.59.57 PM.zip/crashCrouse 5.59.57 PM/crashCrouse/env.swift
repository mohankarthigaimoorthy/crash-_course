//
//  env.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation

public enum Env: String, Codable {
    case stage = "stage"
    case prod = "prod"
}
