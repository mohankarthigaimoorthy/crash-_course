//
//  twoViewResponse.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation

class twoPageResponse : NSObject {

}
