//
//  twoViewController.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/06/23.
//

import UIKit
import AVKit
//import FirebaseDynamicLinks


//var isVideoLoaded = true
//var isPageLoaded = false
//var twoViewData = .init(fromDictionary: [String : Any]())
//var videoFinished = true
//var res = ()

class twoViewController: UIViewController {
    
    @IBOutlet weak var searchView: UISearchBar!
    @IBOutlet weak var products: UICollectionView!
    @IBOutlet weak var pageCollection: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var collectioncvcell: UICollectionView!
    @IBOutlet weak var viewBtn: UIButton!
    @IBOutlet weak var subProd: UICollectionView!
    @IBOutlet weak var btnView: UIButton!
    @IBOutlet weak var prdSub: UICollectionView!
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var layerCollection: UICollectionView!
    @IBOutlet weak var design: UICollectionView!
    
  var welcomeDtata: Welcome?
let welcomeData = Welcome(status: true, message: "Welcome Message", response: Response(cityID: 123, occation: [], category: [], popup: [], banner: [], occasions: [], bestSeller: [], youMayLike: [], cartCount: "0", subcriptionCount: "0", brand: [], activeOrders: [], feedbackOrders: [], iosUpdate: 0, forceIosUpdate: 0), count: "0")
//    var res : Welcome = Response.banner = []
    var bgimgjpeg = ["image11","image12","image11","image12","image11","image12","image11","image12","image11","image12","image11","image12"]
    var image = ["image1","image2","image3","image4","image5","image6","image1","image2","image3","image4","image5","image6"]
    var imaged = ["image6","image7","image8","image9","image10","image6","image7","image8","image9","image10"]
    var text = ["ALL","FLOWER","BASKET","SELF CARE","FLOWERS","SPUSES","HIBISCUS","DOZEN","POKETS","GIFTS","BOKEYS","TRACKES",]
    var content = ["You can get everything in life you want if you will just help enough other people get what they want.","Inspiration does exist, but it must find you working.","Don't settle for average","Show up, show up, show up, and after a while the muse shows up, too.","Don't bunt.","Success is No Accident. ...","Success is Not Final, Failure is Not Fatal: it is the Courage to Continue that Counts. ...","Don't Count the Days, Make the Days Count. ...","He Who is Not Courageous Enough to Take Risks Will Accomplish Nothing in Life. ...","Don't Wait for Opportunity, Create it."]
    var rate = ["SR 320","SR 420","SR 360", "SR 460","SR 340","SR 320","SR 420","SR 360", "SR 460","SR 340","SR 320"]
    var price = ["SR 260","SR 360", "SR 300", "SR 400","SR 280","SR 260","SR 360", "SR 300", "SR 400","SR 280", "SR 290"]
    var currentpage = 0
        override func viewDidLoad() {
        super.viewDidLoad()
        collectionviewswtup()
setupView()
            self.products.register(UINib(nibName: "cellCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cellCollectionViewCell")
            self.pageCollection.register(UINib(nibName: "cell1CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell1CollectionViewCell")
            self.collectioncvcell.register(UINib(nibName: "cell2CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell2CollectionViewCell")
            self.subProd.register(UINib(nibName: "cell3CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell3CollectionViewCell")
            self.prdSub.register(UINib(nibName: "cell3CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell3CollectionViewCell")
            self.layerCollection.register(UINib(nibName: "cell4CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell4CollectionViewCell")
            self.design.register(UINib(nibName: "cell5CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell5CollectionViewCell")
            // Do any additional setup after loading the view.
          
        if let flowLayout = pageCollection?.collectionViewLayout as? UICollectionViewFlowLayout {
                      flowLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
            }
        if let flowLayout = collectioncvcell?.collectionViewLayout as? UICollectionViewFlowLayout {
                      flowLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
            }
            if let flowLayout = design?.collectionViewLayout as? UICollectionViewFlowLayout {
                          flowLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
                }
            viewBtn.layer.cornerRadius = 18
            btnView.layer.cornerRadius = 18
            subView.layer.cornerRadius = 12
            
    }
    
    func collectionviewswtup() {
        products.delegate = self
        products.dataSource = self
        pageCollection.delegate = self
        pageCollection.dataSource = self
        collectioncvcell.delegate = self
        collectioncvcell.dataSource = self
        subProd.delegate = self
        subProd.dataSource = self
        prdSub.delegate = self
        prdSub.dataSource = self
        layerCollection.delegate = self
        layerCollection.dataSource = self
        design.delegate = self
        design.dataSource = self
        DispatchQueue.main.async {
            self.products.reloadData()
            self.pageCollection.reloadData()
            self.collectioncvcell.reloadData()
            self.subProd.reloadData()
            self.prdSub.reloadData()
            self.layerCollection.reloadData()
            self.design.reloadData()
        }
    }
    

    func updatePage() {
        pageControl.currentPage = currentpage
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    fileprivate func setupView() {
        triggerHomeAPI()
    }
    fileprivate func triggerHomeAPI(){
        let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? ""
        let apiRequest = APIRequest(path: .homePageAPI, attachLastPath: "ios_version=\(appVersion)", method: .get, headers: .withToken)
        APIDispatcher.instance.dispatch(request: apiRequest) { (result) in
           switch result {
           case .success(let response):
               print(response)
               if let getrresponse = response ["response"] as? [String: Any] {
                   print(getrresponse)
                   if let getresponse =  getrresponse ["banner"] as? [[String: Any]] {
                       print(getresponse)
                       for index in 0..<getresponse.count{
                           if let getresp = getresponse[index]["image"] as? String {
                               print(getresp)
                               
                           }
//                            if let  getres = getresponse[index]["url"] as? String {
//                               print(getres)
//                           }

                       }
                   }
               }
           case .failure(let apiError):
               print(apiError.localizedDescription)
           }
        }
    }
}

extension twoViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView.tag == 110{
                            return welcomeData.response.banner.count

//            var IndexPath: <# Type #> = 0 {
//                return text.count
//
//            }
//            else{
//                return welcomeData.response.banner.count
//            }
        }
        else if collectionView.tag == 111 {
            return welcomeData.response.activeOrders.count
//            return content.count
        }
        else if collectionView.tag == 112 {
            return content.count
        }
        else if collectionView.tag == 113 {
            return content.count
        }
        else if collectionView.tag == 114 {
            return content.count
        }
        else if collectionView.tag == 115 {
            return content.count
        }
        else if collectionView.tag == 116 {
            return content.count
        }
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView.tag == 110 {
            let cell = products.dequeueReusableCell(withReuseIdentifier: "cellCollectionViewCell", for: indexPath) as! cellCollectionViewCell
            let banner = welcomeData.response.banner[indexPath.item]
            cell.image.image = UIImage(named: "\(self.image[indexPath.item])")  ?? UIImage()
//            cell.image.image = UIImage(name: banner.image) ?? UIImage()
            cell.image.layer.cornerRadius = cell.image.frame.size.height / 2
//            cell.topic.text = self.text[indexPath.item]
            cell.topic.text = banner.occasionsID
            return cell
        }
        else if collectionView.tag == 111 {
            let cells = pageCollection.dequeueReusableCell(withReuseIdentifier: "cell1CollectionViewCell", for: indexPath) as! cell1CollectionViewCell
            let activeorder = welcomeData.response.activeOrders[indexPath.item]
//            cells.descriptionLbl.text = self.content[indexPath.item]
            cells.descriptionLbl.text =  "\(activeorder.value)"
            cells.pageimg.image = UIImage(named: "\(self.bgimgjpeg[indexPath.item])" ) ?? UIImage()
            cells.buynow.layer.cornerRadius = 18

            return cells
        }
        else if collectionView.tag == 112 {
            let cels = collectioncvcell.dequeueReusableCell(withReuseIdentifier: "cell2CollectionViewCell", for: indexPath) as! cell2CollectionViewCell
            cels.imgPrd.image = UIImage(named: "\(self.bgimgjpeg[indexPath.item])" ) ?? UIImage()
            cels.msgTxt.text = self.text[indexPath.item]
            cels.msTxt.text = self.content[indexPath.item]
            return cels
        }
        else if collectionView.tag == 113 {
            let index = subProd.dequeueReusableCell(withReuseIdentifier: "cell3CollectionViewCell", for: indexPath) as! cell3CollectionViewCell
            let attributeString: NSMutableAttributedString = NSMutableAttributedString(string: "\(rate[indexPath.row])")
                attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 2, range: NSRange(location: 0, length: attributeString.length))
            index.emoji.image = UIImage(named: "\(self.image[indexPath.item])") ?? UIImage()
            index.Lbl1.text = self.text[indexPath.item]
            index.Lbl2.text = self.rate[indexPath.item]
            index.Lbl2.attributedText = attributeString
            index.Lbl3.text = self.price[indexPath.item]
            return index
        }
        else if collectionView.tag == 114 {
            let indice = prdSub.dequeueReusableCell(withReuseIdentifier: "cell3CollectionViewCell", for: indexPath) as! cell3CollectionViewCell
            let attributeString: NSMutableAttributedString = NSMutableAttributedString(string: "\(rate[indexPath.row])")
                attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 2, range: NSRange(location: 0, length: attributeString.length))
            indice.emoji.image = UIImage(named: "\(self.image[indexPath.item])") ?? UIImage()
            indice.Lbl1.text = self.text[indexPath.item]
            indice.Lbl2.text = self.rate[indexPath.item]
            indice.Lbl2.attributedText = attributeString
            indice.Lbl3.text = self.price[indexPath.item]
            return indice
        }
        else if collectionView.tag == 115 {
            let cel = layerCollection.dequeueReusableCell(withReuseIdentifier: "cell4CollectionViewCell", for: indexPath) as! cell4CollectionViewCell
            cel.mineImg.image = UIImage(named: self.imaged[indexPath.row])  ?? UIImage()
            cel.mineImg.layer.cornerRadius =  cel.mineImg.frame.size.height / 2
            cel.subTitle.text  = self.text[indexPath.item]
            return cel
        }
        else if collectionView.tag == 116 {
            let task = design.dequeueReusableCell(withReuseIdentifier: "cell5CollectionViewCell", for: indexPath) as! cell5CollectionViewCell
            task.bgImg.image = UIImage(named: "\(self.bgimgjpeg[indexPath.row])") ?? UIImage()
            task.maintext.text = self.content[indexPath.item]
            task.subtext.text = self.text[indexPath.item]
            task.optionBtn.layer.cornerRadius = 15
            return task
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        self.pageControl.currentPage = indexPath.section

    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if collectionView.tag == 110 {
            if let flowLayout = products?.collectionViewLayout as? UICollectionViewFlowLayout {
                          flowLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
                }
                   return CGSize(width: 0
                                 , height: 0)

               }
        else if collectionView.tag == 111 {
            return CGSize(width: 414, height: 300)
        }
        else if collectionView.tag == 112 {
            return CGSize(width: 414, height: 300)

        }
        else if collectionView.tag == 113 {
            return CGSize(width: 200, height: 250)

        }
        else if collectionView.tag == 114 {
            return CGSize(width: 200, height: 220)

        }
        else if collectionView.tag == 115 {
            return CGSize(width: 100, height: 100)

        }
        else if collectionView.tag == 116 {
            return CGSize(width: 414, height: 400)

        }
        return CGSize(width: 414, height: 100)
    }
    
}
