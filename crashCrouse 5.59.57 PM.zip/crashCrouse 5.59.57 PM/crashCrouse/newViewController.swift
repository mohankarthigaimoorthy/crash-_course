////
////  newViewController.swift
////  crashCrouse
////
////  Created by Imcrinox Mac on 05/06/23.
////
//
//import UIKit
//
//class newViewController: UIViewController {
//
//    @IBOutlet weak var prod: UITableView!
//    
//    var data : [Data] = []
//    var prouct = [Product]()
//    var person1 : Data = Data(image: "image1", concern: "predator", text: "001", content: "1",ratings: Int(3.5))
//    var person2 : Data = Data(image: "image2", concern: "starwars", text: "002", content: "2", ratings: Int(4.3))
//    var person3 : Data = Data(image: "image3", concern: "avengersEndgame", text: "003", content: "3", ratings: Int(4.2))
//    var person4 : Data = Data(image: "image4", concern: "avenger infinitys war", text: "004", content: "4", ratings: Int(4))
//    var person5 : Data = Data(image: "image5", concern: "avatar water of ocean ", text: "005", content: "5", ratings: Int(3.9))
//    var person6 : Data = Data(image: "image6", concern: "ironman age of ultrons", text: "006", content: "6", ratings: Int(2.0))
//    
//    var image = ["image1","image2","image3","image4","image5","image6"]
//    var topic = ["the witch","the last day to die", "death note","the wednesday", "the glory","the central sillywork"]
//    var pages = [1,2,3,4,5,6]
//    var synopsis = ["one","two","three","four","five","six"]
//    var ratings = [4.5,4.2,4.0,3.0,3.5,2.8]
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
////        urled()
//        
//fetchAPIResponse()
////        downloadJSON {
////            self.prod.reloadData()
////        }
//     
//    }
//    
//   
//
//    // Create a URLSession instance
////    let session = URLSession.shared
//
//    func fetchAPIResponse() {
//        guard let url = URL(string: "https://dummyjson.com/products") else {             print("Invalid URL")
//return }
//        
//        let task = URLSession.shared.dataTask(with: url) { data, response, error in
//            
//            guard let data = data, error == nil else { return }
//            
//            do {
//                // make sure this JSON is in the format we expect
//                // convert data to json
//                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
//                    // try to read out a dictionary
//                    print(json)
//                    if let data = json["data"] as? [String:Any] {
//                        print(data)
//                        if let prices = data["prices"] as? [[String:Any]] {
//                            print(prices)
//                            let dict = prices[0]
//                            print(dict)
//                            if let price = dict["price"] as? String{
//                                print(price)
//                            }
//                        }
//                    }
//                }
//            } catch let error as NSError {
//                print("Failed to load: \(error.localizedDescription)")
//            }
//            
//        }
//        
//        task.resume()
//    }
//    
////    func fetchAPIResponse() {
////        guard let url = URL(string: "https://dummyjson.com/products") else {
////            print("Invalid URL")
////            return
////        }
////
////        let session = URLSession.shared
////
////        let task = session.dataTask(with: url) { [weak self] (data, response, error) in
////            if let error = error {
////                print("Error: \(error.localizedDescription)")
////                return
////            }
////
////            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
////                if let responseData = data {
////                    do {
////                        let json = try JSONSerialization.jsonObject(with: responseData, options: [])
//////                        if let products = json as? [[String: Any]] {
////                            DispatchQueue.main.async {
//////                                self?.products = products
////                                self?.prod.reloadData()
////                            }
//////                        }
////                    } catch {
////                        print("Error parsing JSON: \(error.localizedDescription)")
////                    }
////                }
////            } else {
////                print("Invalid HTTP response")
////            }
////        }
////
////        task.resume()
////    }
////    func urled() {
////        // Create a URL object with the API endpoint
////        guard let url = URL(string: "https://dummyjson.com/products") else {
////            print("Invalid URL")
////            return
////        }
////        // Create a data task with the URL
////        let task = session.dataTask(with: url) { (data, response, error) in
////            // Check for errors
////            if let error = error {
////                print("Error: \(error.localizedDescription)")
////                return
////            }
////
////            // Check the HTTP response
////            if let httpResponse = response as? HTTPURLResponse {
////                if httpResponse.statusCode == 200 {
////                    // API request was successful
////                    if let responseData = data {
////                        // Parse and process the responseData as needed
////                        do {
////                            let json = try JSONSerialization.jsonObject(with: responseData, options: [])
////                            if let products = json as? [[String: Any]] {
////                                // Access individual product objects
////                                for product in products {
////                                    if let name = product["name"] as? String {
////                                        print("Product name: \(name)")
////                                    }
////                                    // Access other properties as needed
////                                }
////                            }
////                        } catch {
////                            print("Error parsing JSON: \(error.localizedDescription)")
////                        }
////                    }
////                } else {
////                    // Handle non-200 status code
////                    print("HTTP status code: \(httpResponse.statusCode)")
////                }
////            }
////        }
////
////        // Start the task
////        task.resume()
////    }
////    func downloadJSON(completed: @escaping () -> ()) {
////
////        let url = URL(string: "https://dummyjson.com/products")
////
////        URLSession.shared.dataTask(with: url!) {
////            (data, response, error) in
////
////            if error == nil {
////                do {
////                    self.prouct = try JSONDecoder().decode([Product].self, from: data!)
////                    DispatchQueue.main.async {
////                        self.prod.reloadData()
////
////                        completed()
////                    }
////                }
////                catch {
////                    print("JSON ERROR")
////                }
////            }
////        }
////        .resume()
////    }
//    func tableviewsteup() {
//        prod.delegate = self
//        prod.dataSource = self
//        DispatchQueue.main.async {
//            self.prod.reloadData()
//        }
//    }
//
//    /*
//    // MARK: - Navigation
//
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destination.
//        // Pass the selected object to the new view controller.
//    }
//    */
//
//}
//extension newViewController : UITableViewDelegate, UITableViewDataSource {
//    
//    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        return 1
//
//    }
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
////        return data.count
//        return prouct.count
////    return 1
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = prod.dequeueReusableCell(withIdentifier: "productsTableViewCell", for: indexPath) as! productsTableViewCell
//        
//        let urlString = "https://dummyjson.com/"
////        let completeLink = urlString + prouct[indexPath.row].category
////
//        cell.text1.text = "\(self.prouct[indexPath.row].id)"
//        cell.text2.text = self.prouct[indexPath.row].title
//        cell.text3.text = "\(self.prouct[indexPath.row].price)"
//        cell.text4.text = "\(self.prouct[indexPath.row].stock)"
//        cell.prodIMG.image = UIImage(named: self.prouct[indexPath.row].thumbnail) ?? UIImage()
////
////        cell.text1.text = self.data[indexPath.row].concern
////        cell.text2.text = self.data[indexPath.row].content
////        cell.text3.text = self.data[indexPath.row].text
////        cell.text4.text = "\(self.data[indexPath.row].ratings)"
////        cell.prodIMG.image = UIImage(named: self.data[indexPath.row].image) ?? UIImage()
////
////        cell.text1.text = self.topic[indexPath.row]
////        cell.text2.text = "\(self.synopsis[indexPath.row])"
////        cell.text3.text = "\(self.pages[indexPath.row])"
////        cell.text4.text = "\(self.ratings[indexPath.row])"
////        cell.prodIMG.image = UIImage(named: self.image[indexPath.row]) ?? UIImage()
//        
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 300
//    }
//}
