//
//  cell2CollectionViewCell.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 08/06/23.
//

import UIKit

class cell2CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imgPrd: UIImageView!
    @IBOutlet weak var msgTxt: UILabel!
    @IBOutlet weak var msTxt: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
