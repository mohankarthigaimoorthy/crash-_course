//
//  cell4CollectionViewCell.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 08/06/23.
//

import UIKit

class cell4CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var mineImg: UIImageView!
    @IBOutlet weak var subTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
