//
//  threeViewController.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 08/06/23.
//

import UIKit
import CHTCollectionViewWaterfallLayout

class threeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, CHTCollectionViewDelegateWaterfallLayout {
    
    private let collectionView: UICollectionView = {
        let layout = CHTCollectionViewWaterfallLayout()
        layout.itemRenderDirection = .rightToLeft
        layout.columnCount = 2
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.register(cell6CollectionViewCell.self, forCellWithReuseIdentifier: cell6CollectionViewCell.identifier)
        return collectionView
    }()
    var text = ["ALL","FLOWER","BASKET","SELF CARE","FLOWERS","SPUSES","HIBISCUS","DOZEN","POKETS","GIFTS","BOKEYS","TRACKES",]
    var image = ["image1","image2","image3","image4","image5","image6","image1","image2","image3","image4","image5","image6"]
    struct Model {
        let imageName: String
        let height: CGFloat
    }
    
    private var models = [Model]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        view.addSubview(collectionView)
        collectionView.delegate = self
        collectionView.dataSource = self
        let images = Array(0...12).map { "image\($0)"}
        models = images.compactMap {
            return Model.init (
        imageName: $0,
        height: CGFloat.random(in: 200...600)
        )
        }
     
        
        super.viewDidLoad()
      
        // Do any additional setup after loading the view.
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.frame = view.bounds
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return models.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cell6CollectionViewCell.identifier, for: indexPath) as? cell6CollectionViewCell else {fatalError()}
        cell.configure(image: UIImage(named: models[indexPath.item].imageName))
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: view.frame.size.width/2, height: models[indexPath.item].height)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
