////
////  struct.swift
////  crashCrouse
////
////  Created by Imcrinox Mac on 06/06/23.
////
//
//import Foundation
//
//struct Data {
//    var image : String
//    var concern : String
//    var text : String
//    var content : String
//    var ratings : Int
//}
