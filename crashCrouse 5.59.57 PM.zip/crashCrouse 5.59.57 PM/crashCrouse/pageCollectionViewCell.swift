//
//  pageCollectionViewCell.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 05/06/23.
//

import UIKit

class pageCollectionViewCell: UICollectionViewCell {
   
  
    
    override class func awakeFromNib() {
    }

    }
