//
//  cell3CollectionViewCell.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 08/06/23.
//

import UIKit

class cell3CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var emoji: UIImageView!
    @IBOutlet weak var Lbl1: UILabel!
    @IBOutlet weak var Lbl2: UILabel!
    @IBOutlet weak var Lbl3: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
