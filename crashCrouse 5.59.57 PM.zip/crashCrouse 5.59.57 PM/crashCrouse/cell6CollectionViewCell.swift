//
//  cell6CollectionViewCell.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 09/06/23.
//

import UIKit
import CHTCollectionViewWaterfallLayout

class cell6CollectionViewCell: UICollectionViewCell {
    static let identifier = "cell6CollectionViewCell"
    
    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)
        contentView.clipsToBounds = true
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        imageView.frame = contentView.bounds
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func prepareForReuse() {
        super.prepareForReuse()
        imageView.image = nil
    }
    
    func configure(image:   UIImage?) {
        imageView.image = image
    }
}
