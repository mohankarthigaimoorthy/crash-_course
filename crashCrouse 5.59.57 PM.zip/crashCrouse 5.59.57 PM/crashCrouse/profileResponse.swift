//
//  profileResponse.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation

class ProfileResponse : NSObject, NSCoding{

    var countryCode : String!
    var emailId : String!
    var fullName : String!
    var mobileNumber : String!
    var profileImage : String!
    var wallet : String!


    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        countryCode = dictionary["country_code"] as? String ?? ""
        emailId = dictionary["email_id"] as? String ?? ""
        fullName = dictionary["full_name"] as? String ?? ""
        mobileNumber = dictionary["mobile_number"] as? String ?? ""
        profileImage = dictionary["profile_image"] as? String ?? ""
        wallet = dictionary["wallet"] as? String ?? ""
    }

    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if countryCode != nil{
            dictionary["country_code"] = countryCode
        }
        if emailId != nil{
            dictionary["email_id"] = emailId
        }
        if fullName != nil{
            dictionary["full_name"] = fullName
        }
        if mobileNumber != nil{
            dictionary["mobile_number"] = mobileNumber
        }
        if profileImage != nil{
            dictionary["profile_image"] = profileImage
        }
        if wallet != nil{
            dictionary["wallet"] = wallet
        }
        return dictionary
    }

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
    {
         countryCode = aDecoder.decodeObject(forKey: "country_code") as? String ?? ""
         emailId = aDecoder.decodeObject(forKey: "email_id") as? String ?? ""
         fullName = aDecoder.decodeObject(forKey: "full_name") as? String ?? ""
         mobileNumber = aDecoder.decodeObject(forKey: "mobile_number") as? String ?? ""
         profileImage = aDecoder.decodeObject(forKey: "profile_image") as? String ?? ""
         wallet = aDecoder.decodeObject(forKey: "wallet") as? String ?? ""

    }

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
    {
        if countryCode != nil{
            aCoder.encode(countryCode, forKey: "country_code")
        }
        if emailId != nil{
            aCoder.encode(emailId, forKey: "email_id")
        }
        if fullName != nil{
            aCoder.encode(fullName, forKey: "full_name")
        }
        if mobileNumber != nil{
            aCoder.encode(mobileNumber, forKey: "mobile_number")
        }
        if profileImage != nil{
            aCoder.encode(profileImage, forKey: "profile_image")
        }
        if wallet != nil{
            aCoder.encode(wallet, forKey: "wallet")
        }

    }

}

