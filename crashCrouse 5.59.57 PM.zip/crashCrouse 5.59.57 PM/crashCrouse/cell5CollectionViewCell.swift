//
//  cell5CollectionViewCell.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 08/06/23.
//

import UIKit

class cell5CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var bgImg: UIImageView!
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var maintext: UILabel!
    @IBOutlet weak var subtext: UILabel!
    @IBOutlet weak var optionBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
