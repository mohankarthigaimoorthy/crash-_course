//
//  TSAlertVC.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation
import UIKit

extension UIViewController{
    
    func showTSAlert(_ title:String,_ yesTitle:String,_ noTitle:String,_ tag:Int, result: @escaping (_ isCancelled: Bool, _ tag:Int) -> ()){
        mainThread {
//            let vc = TSAlertVC(nibName: "TSAlertVC", bundle: nil)
//            vc.view.bounds = self.view.bounds
//            vc.configView(title, yesTitle, noTitle, tag)
//            vc.modalPresentationStyle = .overFullScreen
//            vc.pickerCompletion = { (isCancel,tag) in
//                result(isCancel,tag)
//            }
//            self.present(vc, animated: true, completion: nil)
        }
    }
}

