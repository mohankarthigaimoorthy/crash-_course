////
////  swift.swift
////  crashCrouse
////
////  Created by Imcrinox Mac on 06/06/23.
////
//
//import Foundation
//import UIKit
//
//class newViewController: UIViewController, UITableViewDataSource {
//
//    @IBOutlet weak var tableView: UITableView!
//    
//    var products: [[String: Any]] = []
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        tableView.dataSource = self
//        
//        fetchAPIResponse()
//    }
//    
//    // MARK: - UITableViewDataSource
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return products.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath)
//        
//        let product = products[indexPath.row]
//        
//        if let name = product["name"] as? String {
//            cell.textLabel?.text = name
//        }
//        
//        // Configure other cell properties as needed
//        
//        return cell
//    }
//    
//    // MARK: - API Request
//    func fetchAPIResponse() {
//        guard let url = URL(string: "https://dummyjson.com/products") else {
//            print("Invalid URL")
//            return
//        }
//        
//        let session = URLSession.shared
//        
//        let task = session.dataTask(with: url) { [weak self] (data, response, error) in
//            if let error = error {
//                print("Error: \(error.localizedDescription)")
//                return
//            }
//            
//            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
//                if let responseData = data {
//                    do {
//                        let json = try JSONSerialization.jsonObject(with: responseData, options: [])
//                        if let products = json as? [[String: Any]] {
//                            DispatchQueue.main.async {
//                                self?.products = products
//                                self?.tableView.reloadData()
//                            }
//                        }
//                    } catch {
//                        print("Error parsing JSON: \(error.localizedDescription)")
//                    }
//                }
//            } else {
//                print("Invalid HTTP response")
//            }
//        }
//        
//        task.resume()
//    }
//   
//}
