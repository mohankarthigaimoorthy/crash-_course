//
//  cell1CollectionViewCell.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 08/06/23.
//

import UIKit

class cell1CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var pageimg : UIImageView!
    @IBOutlet weak var descriptionLbl : UILabel!
    @IBOutlet weak var buynow : UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
