//
//  APIManager.swift
//  TC User APP
//
//  Created by Kavin on 01/12/20.
//  Copyright © 2020 Imcrinox. All rights reserved.
//


import UIKit

var isAppExpired = false
/*
 Screen Link: - https://xd.adobe.com/view/bbc635d1-cac6-48b0-b8b1-c11821ca4355-ee95/grid
 https://api.bloss-sa.com/app/v0_1/api/home_page
 */

enum APIURLType: String {
//    case liveApi = "https://api.bloss-sa.com/app/v0_1/api/"
    case liveApi = "https://staging-api.bloss-sa.com/app/v0_1/api/"
    case storeURL = "https://apps.apple.com/us/app/bloss/id1632412029"

    var baseUrl: String {
        return self.rawValue
    }
}
enum APIPath: String {
    case checkMobileAPI = "check_mobile.php"
    case sendOTPAPI = "send_otp.php"
    case verifyOTPAPI = "verify_otp.php"
    case loginWithOTPApi = "login_verify_otp.php"
    case registerAPI = "registration.php"
    case homePageAPI = "home_page.php"
    case occasionListAPI = "occasion_list.php"
    case productListsAPI = "product_list.php"
    case productDetailAPI = "product_detail.php"
    case insertCartAPI = "insert_cart.php"
    case cartAPI = "cart.php"
    case updateCartAPI = "update_cart.php"
    case applyCouponAPI = "coupon_cart.php"
    case insertAddressAPI = "user_address.php"
    case addressListsAPI = "user_address_list.php"
    case orderListsAPI = "order_list.php"
    case orderDetailAPI = "order_detail.php"
    case checkWishlistAPI = "check_wishlist.php"
    case wishlistAPI = "wishlist.php"
    case orderTimingsAPI = "order_timings.php"
    case addRemainder = "remider.php"
    case orderSubmitAPI = "order_submit.php"
    case checkPaymentAPI = "check_payment.php"
    case tabbyPaymentCheckAPI = "tabby_app_check.php"
    case checkAPPPaymentAPI = "app_payment_check.php"
    case menuAPI = "menu.php"
    case filterAPI = "filter.php"
    case walletHistoryAPI = "wallet_history.php"
    case contactUsAPI = "contact_us.php"
    case pushAPI = "push.php"
    case adOnListsAPI = "add_ons_list.php"
    case subscriptionAPI = "subscription.php"
    case insertSubscriptionAPI = "insert_subscription.php"
    case insertProductSubscriptionAPI = "insert_product_subscription.php"
    case insertCartMessageAPI = "card_message.php"
    case insertReviewAPI = "insert_review.php"
    case updateAddressAPI = "update_address.php"
    case deleteOrderAPI = "delete_order.php"
    
    case loginAPI = "login.php"
    case getCityAPI = "city.php"
    case updateCityAPI = "update_city.php"
    case categoryAPI = "category.php"
    case subCategoyAPI = "sub_category.php"
    case addCartAPI = "add_cart.php"
    case getProfileAPI = "get_profile.php"
    case deleteAddressAPI = "delete_user_address.php"
    case addWalletAPI = "update_wallet.php"
    case selectWalletAPI = "select_wallet.php"
    case logoutAPI = "logout.php"
    case offerListsAPI = "offer_list.php"
    case searchAPI = "search.php"
    case statisticsAPI = "statistics.php"
    case deleteAccountAPI = "delete_account.php"

    func directURL(type: APIURLType) -> URL? {
        let urlPath = type.baseUrl + self.rawValue
        return URL(string: urlPath)
    }
    
    func extendedURL(type: APIURLType, attach path: String) -> URL? {
        let urlPath = type.baseUrl + self.rawValue + "?" + path
        return URL(string: urlPath)
    }
    
    func extendedURL(type: APIURLType, using parameters: [String:String]) -> URL? {
        let urlPath = parameters.reduce(type.baseUrl + self.rawValue) { (urlPath, parameter) -> String in
            return urlPath + "?" + parameter.key + "=" + parameter.value
        }
        return URL(string: urlPath)
    }
    
}

enum APIMethod: String {
    case get = "GET"
    case put = "PUT"
    case post = "POST"
    case patch = "PATCH"
    case delete = "DELETE"
}

enum APIHeaders {
    case withToken
    case withoutToken
    
    var authorization: [String:String] {
        switch self {
        case .withoutToken:
            print("$$$$$$")
            return ["Content-Type":"application/json","Authentication" : "","Token":"","app":"1"]
        case .withToken:
            let getAuthKey = UserDefaults.standard.object(forKey: "user_token") as? String ?? ""
            print("$$$$$$")
          
            print("$$$$$$")
            return ["Content-Type":"application/json","Token":getAuthKey,"app":"1"]
        }
    }
}

struct APIRequest {
    
    var url: URL?
    var method: String
    var parameters: Data?
    var headers: [String:String]
    
    init(urlType: APIURLType = .liveApi, path: APIPath, method: APIMethod, headers: APIHeaders) {
        self.url = path.directURL(type: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
    
    init(urlType: APIURLType = .liveApi, path: APIPath, attachLastPath lastPath: String, method: APIMethod, headers: APIHeaders) {
        self.url = path.extendedURL(type: urlType, attach: lastPath)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
    
    init(urlType: APIURLType = .liveApi, path: APIPath, attachParameters parameters: [String:String], method: APIMethod, headers: APIHeaders) {
        self.url = path.extendedURL(type: urlType, using: parameters)
        #if DEBUG
            print(self.url?.absoluteString as Any)
//            print(JSON(parameters))
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
    
    init(urlType: APIURLType = .liveApi, path: APIPath, method: APIMethod, parameters: [String:Any], headers: APIHeaders) {
        self.url = path.directURL(type: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
//            print(JSON(parameters))
        #endif
        self.method = method.rawValue
        self.parameters = try? JSONSerialization.data(withJSONObject: parameters, options: .sortedKeys)
        self.headers = headers.authorization
    }
    
    init<Encode: Encodable>(urlType: APIURLType = .liveApi, path: APIPath, method: APIMethod, parameters: Encode, headers: APIHeaders) {
        self.url = path.directURL(type: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.parameters = try? JSONEncoder().encode(parameters)
        self.headers = headers.authorization
    }

    init(urlType: String, method: APIMethod, headers: APIHeaders) {
        self.url = URL(string: urlType)
        #if DEBUG
            print(self.url?.absoluteString as Any)
        #endif
        self.method = method.rawValue
        self.headers = headers.authorization
    }
}


struct APIError: Error {
    let reason: String
    init(reason: String) {
        self.reason = reason
    }
}


struct APIDispatcher {
    
    static let instance = APIDispatcher()
    private init() {}
    
    func dispatch<Decode: Decodable>(request: APIRequest, response: Decode.Type, result: @escaping (Result<Decode, APIError>) -> ()) {
        self.connectToServer(with: request) { (resultant) in
            switch resultant {
            case .success(let data):
                do {
                    let decoded = try JSONDecoder().decode(response, from: data)
                    DispatchQueue.main.async {
                        result(.success(decoded))
                    }
                } catch {
                    let apiError = APIError(reason: error.localizedDescription)
                    DispatchQueue.main.async {
                        result(.failure(apiError))
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    result(.failure(error))
                }
            }
        }
    }
    
    func dispatch(request: APIRequest, result: @escaping (Result<Dictionary<String,Any>, APIError>) -> ()) {
        if !isInternetReachable() {
            self.showInternetView()
            return
        }
        self.connectToServer(with: request) { (resultant) in
            switch resultant {
            case .success(let data):
                do {
                    if let serialized = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String,Any> {
                        DispatchQueue.main.async {
                            result(.success(serialized))
                        }
                    } else {
                        let apiError = APIError(reason: "No Data as Dictionary<String, Any>")
                        DispatchQueue.main.async {
                            result(.failure(apiError))
                        }
                    }
                } catch {
                    let error = APIError(reason: error.localizedDescription)
                    DispatchQueue.main.async {
                        result(.failure(error))
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    result(.failure(error))
                }
            }
        }
    }
    
    private func connectToServer(with request: APIRequest, result: @escaping (Result<Data, APIError>) -> ()) {
        guard let url = request.url else {
            let error = APIError(reason: "Invalid URL")
            result(.failure(error))
            return
        }
        let getUrlStr = request.url?.absoluteString as? String ?? ""
        var showLoader = true
        if getUrlStr.contains("home_page.php"){
            showLoader = false
        }else if getUrlStr.contains("add_ons_list.php"){
            showLoader = false
        }else if getUrlStr.contains("get_profile.php"){
            showLoader = false
        }else if getUrlStr.contains("remider.php"){
            showLoader = false
        }else if getUrlStr.contains("push.php"){
            showLoader = false
        }
        if showLoader{
            self.showLoading()
        }
        var urlRequest = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 30)
        urlRequest.httpMethod = request.method
        urlRequest.httpBody = request.parameters
        urlRequest.allHTTPHeaderFields = request.headers
        
        let urlSessionConfiguration = URLSessionConfiguration.default
        urlSessionConfiguration.waitsForConnectivity = true
        urlSessionConfiguration.timeoutIntervalForRequest = 30
        urlSessionConfiguration.timeoutIntervalForResource = 60
        
        let urlSession = URLSession(configuration: urlSessionConfiguration)
        urlSession.dataTask(with: urlRequest) { (data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                print("Status Code: " + "\(httpResponse.statusCode)")
            }
//            if !getUrlStr.contains("home_page.php") || !getUrlStr.contains("add_ons_list.php"){
                self.removeLoading()
//            }
            guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
                var errorDescription = ""
                if let httpResponse = response as? HTTPURLResponse {
                    if httpResponse.statusCode == 503{
                        isAppExpired = true
                        DispatchQueue.main.async {
                            if let topVC = UIApplication.topViewController() {
                                topVC.showSimpleAlert(withTitle: "Session expired. Please login to continue", vc: topVC, type: 15)
                            }
                        }
                        return
                    }
                    errorDescription = ("Status Code: " + httpResponse.statusCode.description + "\n")
                }
                if let data = data, let errorResponse = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String, Any> {
                    errorDescription += (errorResponse.compactMap({ (key, value) -> String in
                        return key + ": " + (value as? String ?? "")
                    })).joined(separator: "\n")
                }
                let apiError = APIError(reason: errorDescription)
                result(.failure(apiError))
                return
        }
            
            if let error = error {
                let apiError = APIError(reason: error.localizedDescription)
                result(.failure(apiError))
                return
            }
            if let data = data {
                if let serialized = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? Dictionary<String, Any>, serialized.contains(where: { $0.key == "error" }), let errorText = ((serialized["message"] as? String) ?? serialized["error"] as? String) {
                    let apiError = APIError(reason: errorText)
                    result(.failure(apiError))
                    return
                }
                let getUrlStr = request.url?.absoluteString as? String ?? ""
                if getUrlStr.contains("update_cart.php") || getUrlStr.contains("insert_cart.php") || getUrlStr.contains("cart.php") || getUrlStr.contains("add_cart.php"){
                    DispatchQueue.main.async {
                        if let topVC = UIApplication.topViewController(){
                            for views in topVC.view.subviews{
//                                if let isFoot = views as? APPFooterView{
//                                    isFoot.triggerHomeAPI()
//                                    break
//                                }
                            }
                        }
                    }
                }
                result(.success(data))
            }
        }.resume()
        
    }
    func showLoading() {
        DispatchQueue.main.async {
            if let topVC = UIApplication.topViewController() {
                let loadingView = UIView(frame: topVC.view.bounds)
                loadingView.tag = 999
                loadingView.accessibilityIdentifier = "loading_view"
                loadingView.backgroundColor = .clear//UIColor.white.withAlphaComponent(0.5)
                let activityIndicatorView = UIActivityIndicatorView(style: .white)
                activityIndicatorView.center = loadingView.center
                activityIndicatorView.color = UIColor(displayP3Red: 48/255, green: 31/255, blue: 101/255, alpha: 1)
                activityIndicatorView.startAnimating()
                loadingView.addSubview(activityIndicatorView)
                topVC.view.insertSubview(loadingView, at: 999)
            }
        }
    }
    func removeLoading() {
        DispatchQueue.main.async {
            if let topVC = UIApplication.topViewController() {
                if let loadingView = topVC.view.subviews.first(where: { $0.tag == 999 && $0.accessibilityIdentifier == "loading_view" }) {
                    loadingView.removeFromSuperview()
                }
            }
        }
    }
    func showInternetView(){
        DispatchQueue.main.async {
            if let topVC = UIApplication.topViewController() {
//                topVC.showToast(message: "No internet connection", isError: true)
            }
        }
    }
}
