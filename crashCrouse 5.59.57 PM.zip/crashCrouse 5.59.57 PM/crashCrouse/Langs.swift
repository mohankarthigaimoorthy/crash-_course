//
//  Langs.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation

public enum Lang: String, Codable {
    case en = "en"
    case ar = "ar"
}
