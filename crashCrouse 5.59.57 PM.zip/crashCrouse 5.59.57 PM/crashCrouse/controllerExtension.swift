//
//  controllerExtension.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation
import UIKit

var isSessionExpired = false
var userLoggedInfo = ProfileResponse.init(fromDictionary: [String : Any]())
extension UIViewController:UIGestureRecognizerDelegate{
    
    func mainThread(_ function: @escaping ()->())
    {
        DispatchQueue.main.async(execute: function)
    }
    func showSimpleAlert(withTitle title: String,vc:UIViewController,type:Int) {
        if isSessionExpired && type == 15{
            return
        }
        if type == 15{
            isSessionExpired = true
        }
        //        DispatchQueue.main.async {
        self.showTSAlert(title, "Ok", "", type) { isCancelled, tag in
            if !isCancelled{
                if tag == 5{
//                    self.dismissVC()
                }else if tag == 10{
//                    self.setRootController(identifier: NavigationHelper.homeVC)
                }else if tag == 15{
                    isSessionExpired = false
//                    let getLangauge = L102Language.currentAppleLanguage()
                    UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
                    UserDefaults.standard.synchronize()
//                    L102Language.setAppleLAnguageTo(lang: getLangauge)
//                    SDImageCache.shared.clearMemory()
//                    SDImageCache.shared.clearDisk()
//                    self.setRootController(identifier: "ViewController")
                }else if tag == 20{
//                    self.popVC()
                }
            }
        }
        
    }
}
