//
//  checkoutError.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation

public enum CheckoutError: Error {
    case invalidUrl
    case invalidResponse
    case noResponse
    case invalidData
    case unableToDecode
    case unableToComplete
}
