//
//  Currencey.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/12/1444 AH.
//

import Foundation


public enum Currency: String, Codable {
  case AED = "AED"
  case SAR = "SAR"
  case BHD = "BHD"
  case KWD = "KWD"
  case EGP = "EGP"
  
  
  public func localized(l: Lang?) -> String {
    if (l == nil || l == .en) {
      return self.rawValue
    }
    switch self {
    case .AED:
      return "د.إ"
    case .SAR:
      return "ر.س"
    case .BHD:
      return "د.ب"
    case .KWD:
      return "د.ك"
    case .EGP:
      return "ج.م"
    }
  }
}

