////
////  twoViewBanner.swift
////  crashCrouse
////
////  Created by Imcrinox Mac on 01/12/1444 AH.
////
//
//import Foundation
//
//class twoViewBanner : NSObject {
//    var image = String!
//    var offerIID : String
//    var url = String !
//    var categoryId : String!
//    var ocassionId: String!
//    var productId : String!
//    
//    init(fromDictionary dictionary:[String: Any]) {
//        image = dictionary["image"] as? String ?? ""
//        let icon = dictionary
//    }
//}
