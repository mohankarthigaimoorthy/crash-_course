//
//  ViewController.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/06/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "oneViewController") as? oneViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }


}

