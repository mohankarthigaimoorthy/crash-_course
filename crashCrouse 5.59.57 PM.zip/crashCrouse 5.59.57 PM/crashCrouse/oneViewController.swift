//
//  oneViewController.swift
//  crashCrouse
//
//  Created by Imcrinox Mac on 01/06/23.
//

import UIKit

class oneViewController: UIViewController {

    @IBOutlet weak var content: UIView!
 
    @IBOutlet weak var verifybtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        content.roundCorners(cornerRadius: 30.0)

//        DispatchQueue.main.async {
//          self.content.layer.cornerRadius = self.content.bounds.size.width / 2.0
//          self.content.clipsToBounds = true
//        }
        
        verifybtn.layer.cornerRadius = 25

    }
    
    
    @IBAction func verify(_ sender: Any) {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIView {
    func roundCorners(cornerRadius: Double) {
        self.layer.cornerRadius = CGFloat(cornerRadius)
        self.clipsToBounds = true
    }
    
}
